#!/usr/bin/env python3
import os,re,signal,subprocess,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
LINK=ROOT/'public-url.txt'
process=None

def save(value):
    temporary=LINK.with_suffix('.tmp')
    temporary.write_text(value+'\n');temporary.replace(LINK)
def stop(*args):
    if process and process.poll() is None:
        process.terminate()
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:process.kill()
    save('')
    raise SystemExit(0)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
save('')
while True:
    try:
        with urllib.request.urlopen('http://127.0.0.1:8787/api/version',timeout=3) as response:
            if response.status==200:break
    except OSError:pass
    time.sleep(2)
process=subprocess.Popen([str(ROOT/'bin/cloudflared'),'tunnel','--url','http://127.0.0.1:8787','--no-autoupdate'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
try:
    for line in process.stdout:
        print(line,end='',flush=True)
        match=re.search(r'https://[a-z0-9-]+\.trycloudflare\.com',line)
        if match:save(match[0])
    code=process.wait()
finally:save('')
raise SystemExit(code or 1)
