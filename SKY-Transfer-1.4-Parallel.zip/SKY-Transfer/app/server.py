#!/usr/bin/env python3
"""SKY Transfer: dependency-free, disk-streamed temporary file sharing."""
import hashlib, hmac, json, mimetypes, os, re, secrets, sqlite3, threading, time, zipfile, weakref
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit, quote

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('CLOUD_STORAGE', str(Path.home() / 'Library/Application Support/PrivateCloud'))).expanduser()
DATA.mkdir(parents=True, exist_ok=True)
os.chmod(DATA, 0o700)
KEYFILE = DATA / 'admin-key'
if not KEYFILE.exists():
    fd = os.open(str(KEYFILE), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as f: f.write(secrets.token_urlsafe(32))
KEY = KEYFILE.read_text().strip()
LIMIT = 100 * 1000**3
MAX_FILE = 20 * 1000**3
CHUNK = 8 * 1024**2
LOCK = threading.RLock()
FILE_LOCKS = weakref.WeakValueDictionary()
DB = sqlite3.connect(str(DATA / 'files.sqlite'), check_same_thread=False)
DB.row_factory = sqlite3.Row
DB.execute('CREATE TABLE IF NOT EXISTS files (id TEXT PRIMARY KEY, name TEXT, size INTEGER, offset INTEGER, days INTEGER, created REAL, expires REAL, complete INTEGER)')
if 'batch_id' not in {r[1] for r in DB.execute('PRAGMA table_info(files)')}:
    DB.execute('ALTER TABLE files ADD COLUMN batch_id TEXT')
DB.execute('CREATE TABLE IF NOT EXISTS batches (id TEXT PRIMARY KEY,title TEXT,expected INTEGER,days INTEGER,created REAL,expires REAL)')
DB.commit()

def cleanup():
    with LOCK:
        now = time.time()
        rows = DB.execute('SELECT id FROM files WHERE (complete=1 AND expires<=?) OR (complete=0 AND created<=?)', (now, now-86400)).fetchall()
        for row in rows:
            (DATA / row['id']).unlink(missing_ok=True)
            DB.execute('DELETE FROM files WHERE id=?', (row['id'],))
        abandoned=DB.execute('SELECT id FROM batches WHERE (expires IS NOT NULL AND expires<=?) OR (expires IS NULL AND created<=?)',(now,now-86400)).fetchall()
        for group in abandoned:
            for item in DB.execute('SELECT id FROM files WHERE batch_id=?',(group['id'],)).fetchall():
                (DATA/item['id']).unlink(missing_ok=True)
            DB.execute('DELETE FROM files WHERE batch_id=?',(group['id'],))
            DB.execute('DELETE FROM batches WHERE id=?',(group['id'],))
        DB.execute('DELETE FROM batches WHERE id NOT IN (SELECT DISTINCT batch_id FROM files WHERE batch_id IS NOT NULL)')
        DB.commit()

def janitor():
    while True:
        cleanup()
        time.sleep(30)

def cookie_value():
    return hmac.new(KEY.encode(), b'private-cloud-session-v1', hashlib.sha256).hexdigest()

class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def setup(self):
        super().setup()
        self.connection.settimeout(120)
    def log_message(self, fmt, *args):
        # Download tokens and request bodies must not appear in logs.
        pass
    def reply(self, code, value, headers=None):
        body = json.dumps(value).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers()
        self.wfile.write(body)
    def authed(self):
        cookies = dict(x.strip().split('=',1) for x in self.headers.get('Cookie','').split(';') if '=' in x)
        return hmac.compare_digest(cookies.get('cloud_session',''), cookie_value())
    def length(self):
        try: return int(self.headers.get('Content-Length', '-1'))
        except ValueError: return -1
    def json_body(self):
        n = self.length()
        if not 0 <= n <= 131072: raise ValueError('Invalid request size')
        return json.loads(self.rfile.read(n))
    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/api/version':
            return self.reply(200, {'name':'SKY Transfer','version':'glass-1.4'})
        if path == '/api/public-url':
            linkfile=ROOT / 'public-url.txt'
            link=linkfile.read_text().strip() if linkfile.exists() else ''
            return self.reply(200, {'url':link if re.fullmatch(r'https://[a-z0-9-]+\.trycloudflare\.com',link) else ''})
        match=re.fullmatch(r'/b/([A-Za-z0-9_-]+)\.zip',path)
        if match:return self.download_batch(match[1])
        if path.startswith('/d/'):

            return self.download(path[3:])
        if path == '/api/files':
            if not self.authed(): return self.reply(401, {'error':'Please sign in'})
            cleanup()
            with LOCK:
                rows = [dict(r) for r in DB.execute('SELECT * FROM files ORDER BY created DESC')]
                batches=[dict(r) for r in DB.execute('SELECT * FROM batches ORDER BY created DESC')]
            return self.reply(200, {'batches':batches, 'files':rows, 'reserved':sum(r['size'] for r in rows), 'used':sum(r['offset'] for r in rows), 'limit':LIMIT, 'maxFile':MAX_FILE})
        assets = {'/':'index.html', '/app.js':'app.js', '/style.css':'style.css', '/favicon.svg':'favicon.svg'}
        if path not in assets: return self.reply(404, {'error':'Not found'})
        p = ROOT / 'web' / assets[path]
        body = p.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', mimetypes.guess_type(str(p))[0] or 'text/plain')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.end_headers()
        self.wfile.write(body)
    def do_POST(self):
        path = urlsplit(self.path).path
        origin = self.headers.get('Origin')
        if origin and urlsplit(origin).netloc != self.headers.get('Host'):
            self.close_connection = True
            return self.reply(403, {'error':'Origin rejected'})
        try:
            if path == '/api/login':
                data = self.json_body()
                if not hmac.compare_digest(str(data.get('key','')), KEY):
                    time.sleep(1)
                    return self.reply(401, {'error':'Incorrect access key'})
                secure = '; Secure' if origin and origin.startswith('https://') else ''
                return self.reply(200, {'ok':True}, {'Set-Cookie':'cloud_session='+cookie_value()+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400'+secure})
            if not self.authed():
                self.close_connection = True
                return self.reply(401, {'error':'Please sign in'})
            if path == '/api/logout':
                if self.length() != 0: self.json_body()
                return self.reply(200, {'ok':True}, {'Set-Cookie':'cloud_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})
            if path == '/api/batches':
                data=self.json_body();items=data.get('files');days=int(data.get('days',1))
                if not isinstance(items,list) or not 2<=len(items)<=100 or days not in (1,2,3):
                    return self.reply(400,{'error':'A group requires 2–100 files and expiry of 1–3 days'})
                metadata=[]
                for item in items:
                    name=str(item['name']).replace('\\','/').split('/')[-1]
                    name=''.join(c for c in name if ord(c)>=32 and ord(c)!=127)[:240] or 'download'
                    if name in ('.','..'):name='download'
                    size=int(item['size'])
                    if not 1<=size<=MAX_FILE:return self.reply(400,{'error':'Each file must be non-empty and no larger than 20 GB'})
                    metadata.append((name,size))
                total=sum(size for name,size in metadata);cleanup()
                with LOCK:
                    reserved=DB.execute('SELECT COALESCE(SUM(size),0) FROM files').fetchone()[0]
                    pending=DB.execute('SELECT COALESCE(SUM(size-offset),0) FROM files').fetchone()[0]
                    disk=os.statvfs(str(DATA));free=disk.f_bavail*disk.f_frsize
                    if reserved+total>LIMIT or pending+total>free-1024**3:
                        return self.reply(409,{'error':'Not enough storage for this entire group. No files were reserved.'})
                    ident=secrets.token_urlsafe(24);now=time.time()
                    title=metadata[0][0]+' + '+str(len(metadata)-1)+' more'
                    created=[]
                    try:
                        DB.execute('INSERT INTO batches VALUES (?,?,?,?,?,?)',(ident,title,len(metadata),days,now,None))
                        for index,(name,size) in enumerate(metadata):
                            fid=secrets.token_urlsafe(24);(DATA/fid).touch(mode=0o600);created.append(fid)
                            DB.execute('INSERT INTO files (id,name,size,offset,days,created,expires,complete,batch_id) VALUES (?,?,?,?,?,?,?,?,?)',(fid,name,size,0,days,now+index*.000001,None,0,ident))
                        DB.commit()
                    except Exception:
                        DB.rollback()
                        for fid in created:(DATA/fid).unlink(missing_ok=True)
                        raise
                    files=[dict(r) for r in DB.execute('SELECT * FROM files WHERE batch_id=? ORDER BY created',(ident,))]
                return self.reply(201,{'id':ident,'files':files})
            match=re.fullmatch(r'/api/batches/([A-Za-z0-9_-]+)/delete',path)
            if match:
                if self.length()!=0:self.json_body()
                with LOCK:
                    for item in DB.execute('SELECT id FROM files WHERE batch_id=?',(match[1],)).fetchall():
                        (DATA/item['id']).unlink(missing_ok=True)
                    DB.execute('DELETE FROM files WHERE batch_id=?',(match[1],))
                    DB.execute('DELETE FROM batches WHERE id=?',(match[1],));DB.commit()
                return self.reply(200,{'ok':True})
            if path == '/api/files':
                data = self.json_body()
                size, days = int(data['size']), int(data['days'])
                name = str(data['name']).replace('\\','/').split('/')[-1]
                name = ''.join(c for c in name if ord(c)>=32 and ord(c)!=127)[:240] or 'download'
                if not 1 <= size <= MAX_FILE or days not in (1,2,3): return self.reply(400, {'error':'Choose a file up to 20 GB and expiry of 1–3 days'})
                cleanup()
                with LOCK:
                    reserved = DB.execute('SELECT COALESCE(SUM(size),0) FROM files').fetchone()[0]
                    disk = os.statvfs(str(DATA))
                    free = disk.f_bavail * disk.f_frsize
                    pending = DB.execute('SELECT COALESCE(SUM(size-offset),0) FROM files').fetchone()[0]
                    if reserved+size>LIMIT or pending+size>free-1024**3:
                        return self.reply(409, {'error':'Not enough storage; delete a transfer or wait for expiry'})
                    ident = secrets.token_urlsafe(24)
                    (DATA / ident).touch(mode=0o600)
                    DB.execute('INSERT INTO files (id,name,size,offset,days,created,expires,complete) VALUES (?,?,?,?,?,?,?,?)', (ident,name,size,0,days,time.time(),None,0))
                    DB.commit()
                return self.reply(201, {'id':ident, 'offset':0})
            match = re.fullmatch(r'/api/files/([A-Za-z0-9_-]+)/chunk', path)
            if match:return self.upload_chunk(match[1])
            match = re.fullmatch(r'/api/files/([A-Za-z0-9_-]+)/delete',path)
            if match:
                if self.length() != 0: self.json_body()
                with LOCK:
                    member=DB.execute('SELECT batch_id FROM files WHERE id=?',(match[1],)).fetchone()
                    if member and member['batch_id']:return self.reply(400,{'error':'Delete the group to remove grouped files'})
                    (DATA / match[1]).unlink(missing_ok=True)
                    DB.execute('DELETE FROM files WHERE id=?',(match[1],))
                    DB.commit()
                return self.reply(200, {'ok':True})
            return self.reply(404, {'error':'Not found'})
        except (ValueError,KeyError,TypeError,json.JSONDecodeError):
            self.close_connection=True
            return self.reply(400, {'error':'Invalid request'})
        except (ConnectionError, BrokenPipeError, ConnectionResetError):
            self.close_connection=True
        except OSError:
            self.close_connection=True
            return self.reply(507, {'error':'Storage write failed; check the disk and resume'})
    def upload_chunk(self,ident):
        n=self.length();offset=int(self.headers.get('Upload-Offset','-1'))
        if not 1<=n<=CHUNK:
            self.close_connection=True
            return self.reply(400,{'error':'Chunk must be 1 byte to 8 MiB'})
        # Serialize only writes to this file; other files can receive bytes concurrently.
        with LOCK:
            file_lock=FILE_LOCKS.get(ident)
            if file_lock is None:
                file_lock=threading.Lock();FILE_LOCKS[ident]=file_lock
        with file_lock:
            with LOCK:
                row=DB.execute('SELECT * FROM files WHERE id=?',(ident,)).fetchone()
                if not row or row['complete'] or offset!=row['offset'] or offset+n>row['size']:
                    self.close_connection=True
                    return self.reply(409,{'error':'Upload offset changed; refresh and resume'})
                f=(DATA/ident).open('r+b')
            with f:
                f.seek(offset);remaining=n
                try:
                    while remaining:
                        block=self.rfile.read(min(1024**2,remaining))
                        if not block:raise ConnectionError('Upload interrupted')
                        f.write(block);remaining-=len(block)
                except Exception:
                    f.truncate(offset)
                    raise
            with LOCK:
                current=DB.execute('SELECT offset FROM files WHERE id=?',(ident,)).fetchone()
                if not current or current['offset']!=offset:
                    return self.reply(409,{'error':'Upload was removed or changed while receiving data'})
                new_offset=offset+n;complete=int(new_offset==row['size'])
                expires=time.time()+row['days']*86400 if complete else None
                DB.execute('UPDATE files SET offset=?,complete=?,expires=? WHERE id=?',(new_offset,complete,expires,ident))
                if complete and row['batch_id']:
                    group=DB.execute('SELECT * FROM batches WHERE id=?',(row['batch_id'],)).fetchone()
                    counts=DB.execute('SELECT COUNT(*),SUM(complete) FROM files WHERE batch_id=?',(row['batch_id'],)).fetchone()
                    if group and counts[0]==group['expected'] and counts[1]==group['expected']:
                        expiry=time.time()+group['days']*86400
                        DB.execute('UPDATE batches SET expires=? WHERE id=?',(expiry,group['id']))
                        DB.execute('UPDATE files SET expires=? WHERE batch_id=?',(expiry,group['id']))
                DB.commit()
        return self.reply(200,{'offset':new_offset,'complete':bool(complete)})

    def download_batch(self, ident):
        opened=[]
        with LOCK:
            group=DB.execute('SELECT * FROM batches WHERE id=?',(ident,)).fetchone()
            files=DB.execute('SELECT * FROM files WHERE batch_id=? ORDER BY created',(ident,)).fetchall()
            if not group or not group['expires'] or group['expires']<=time.time():
                return self.reply(410,{'error':'This group is still uploading, expired, or was deleted'})
            if len(files)!=group['expected'] or any(not r['complete'] or r['expires']<=time.time() for r in files):
                return self.reply(410,{'error':'This group is incomplete or expired'})
            try:
                for item in files:opened.append((item,(DATA/item['id']).open('rb')))
            except OSError:
                for item,f in opened:f.close()
                return self.reply(410,{'error':'A file in this group is unavailable'})
        self.close_connection=True
        self.send_response(200)
        self.send_header('Content-Type','application/zip')
        archive_name='SKY Transfer '+time.strftime('%Y-%m-%d',time.localtime(group['created']))+'.zip'
        self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(archive_name,safe=''))
        self.send_header('Cache-Control','private, no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Connection','close')
        self.end_headers()
        try:
            with zipfile.ZipFile(self.wfile,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as archive:
                used=set()
                for item,f in opened:
                    original=item['name'].replace('\\','/').split('/')[-1].replace(':','_').rstrip(' .')
                    if original in ('.','..',''):original='download'
                    candidate=original;number=2;stem=Path(original).stem;suffix=Path(original).suffix
                    while candidate.casefold() in used:
                        candidate=stem+' ('+str(number)+')'+suffix;number+=1
                    used.add(candidate.casefold())
                    with archive.open(candidate,'w',force_zip64=True) as entry:
                        while True:
                            block=f.read(1024**2)
                            if not block:break
                            entry.write(block)
        except (BrokenPipeError,ConnectionResetError):pass
        finally:
            for item,f in opened:f.close()

    def download(self, ident):
        if not re.fullmatch('[A-Za-z0-9_-]+',ident): return self.reply(404, {'error':'Link not found'})
        with LOCK:
            row=DB.execute('SELECT * FROM files WHERE id=? AND complete=1',(ident,)).fetchone()
            if not row or row['expires']<=time.time(): return self.reply(410, {'error':'This link has expired or was deleted'})
            try: f=(DATA / ident).open('rb')
            except FileNotFoundError: return self.reply(410, {'error':'File unavailable'})
        with f:
            start,end=0,row['size']-1
            range_header=self.headers.get('Range')
            if range_header:
                match=re.fullmatch(r'bytes=(\d*)-(\d*)',range_header)
                if not match or not any(match.groups()): return self.reply(416, {'error':'Invalid range'}, {'Content-Range':f"bytes */{row['size']}"})
                if match[1]:
                    start=int(match[1]); end=min(end,int(match[2])) if match[2] else end
                else: start=max(0,row['size']-int(match[2]))
                if start>end: return self.reply(416, {'error':'Invalid range'}, {'Content-Range':f"bytes */{row['size']}"})
            self.send_response(206 if range_header else 200)
            self.send_header('Content-Type','application/octet-stream')
            self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(row['name'],safe=''))
            self.send_header('Content-Length',str(end-start+1))
            self.send_header('Accept-Ranges','bytes')
            self.send_header('Cache-Control','private, no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Referrer-Policy','no-referrer')
            if range_header: self.send_header('Content-Range',f"bytes {start}-{end}/{row['size']}")
            self.end_headers()
            f.seek(start)
            remaining=end-start+1
            try:
                while remaining:
                    block=f.read(min(1024**2,remaining))
                    if not block: break
                    self.wfile.write(block); remaining-=len(block)
            except (BrokenPipeError,ConnectionResetError): pass

if __name__=='__main__':
    cleanup()
    threading.Thread(target=janitor,daemon=True).start()
    port=int(os.environ.get('PORT','8787'))
    server=ThreadingHTTPServer((os.environ.get('CLOUD_BIND','127.0.0.1'),port),Handler)
    server.daemon_threads=True
    print(f'SKY Transfer running on port {port}. Access key is in {KEYFILE}',flush=True)
    server.serve_forever()
