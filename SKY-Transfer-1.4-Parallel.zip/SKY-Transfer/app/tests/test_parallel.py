import tempfile,os,importlib.util,threading,http.client,json,socket,time
from pathlib import Path
with tempfile.TemporaryDirectory() as tmp:
    os.environ['CLOUD_STORAGE']=tmp
    spec=importlib.util.spec_from_file_location('parallel_server',str(Path(__file__).resolve().parents[1]/'server.py'))
    c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    server=c.ThreadingHTTPServer(('127.0.0.1',0),c.Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
    port=server.server_port;cookie=''
    def req(method,path,body=None):
        headers={'Cookie':cookie}
        if isinstance(body,dict):body=json.dumps(body);headers['Content-Type']='application/json'
        conn=http.client.HTTPConnection('127.0.0.1',port,timeout=3);conn.request(method,path,body,headers)
        response=conn.getresponse();result=(response.status,dict(response.getheaders()),response.read());conn.close();return result
    _,headers,_=req('POST','/api/login',{'key':c.KEY});cookie=headers['Set-Cookie'].split(';')[0]
    _,_,body=req('POST','/api/batches',{'days':1,'files':[{'name':str(i)+'.txt','size':4} for i in range(3)]})
    files=json.loads(body)['files'];connections=[]
    try:
        for row in files:
            conn=socket.create_connection(('127.0.0.1',port),timeout=3)
            conn.sendall(('POST /api/files/'+row['id']+'/chunk HTTP/1.1\r\nHost: localhost\r\nCookie: '+cookie+'\r\nUpload-Offset: 0\r\nContent-Length: 4\r\nConnection: close\r\n\r\na').encode())
            connections.append(conn)
        # All sockets are intentionally incomplete. Each must make disk progress;
        # one stalled sender must not hold the global DB lock or block other files.
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            if all((Path(tmp)/row['id']).stat().st_size==1 for row in files):break
            time.sleep(.02)
        # Python buffering may defer physical size until close, so inspect active per-file locks.
        with c.LOCK:assert len(c.FILE_LOCKS)==3,'All three files must be receiving concurrently'
        assert req('GET','/api/files')[0]==200,'Metadata remains responsive during stalled uploads'
        for conn in connections:conn.sendall(b'bcd')
        for conn in connections:
            content=b''
            while True:
                block=conn.recv(65536)
                if not block:break
                content+=block
            assert b'200 OK' in content and b'"complete": true' in content,content
        assert all((Path(tmp)/row['id']).read_bytes()==b'abcd' for row in files)
        print('PASS: three files receive concurrently, a slow sender does not block metadata, exact stored bytes, shared group completion.')
    finally:
        for conn in connections:conn.close()
        server.shutdown();c.DB.close()
