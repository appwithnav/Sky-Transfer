SKY TRANSFER — GLASS 1.4

Extract this entire ZIP first. Open only:

    Start SKY Transfer.command

Keep the app folder beside that command until installation finishes.
The launcher installs/updates the app in ~/Library/Application Support/SKY Transfer,
replaces the previous login services, stops a recognized old manual SKY Transfer
server on port 8787, starts both the local app and internet tunnel, and opens
the new glass interface. It can be closed after setup. The services keep running.

You should see “Glass 1.4” on the page. If not, press Command-Shift-R once.
The current public address appears at the top, under “Open public page”.
Copied file links use that public address when it is available.
The temporary address changes after tunnel restarts. Previously shared links
then need the new address. Internet connection is required for the tunnel.

No router settings, domain, Cloudflare account, or admin password are needed.
Your existing access key and uploaded files are preserved in the original
~/Library/Application Support/PrivateCloud storage folder.
No access key or uploaded files are included in this package.

AUTOMATIC STARTUP
Both services start when you log in to this Mac, not before login.
They restart after unexpected exits. Idle sleep is prevented while running;
manual sleep, closing a laptop lid, shutdown, or loss of internet can stop transfers.
The screen may turn off normally. Do not run older launchers alongside this version.
A Mac restart/login is required to test automatic startup end to end.

IF DOUBLE-CLICK DOES NOT OPEN THE SCRIPT
Open Terminal, type “zsh ” (with a trailing space), drag
Start SKY Transfer.command into Terminal, and press Return.
The launcher reports any setup failure in its window.
Python 3.9 or later must be installed. Tested with Intel macOS and Python 3.9.6.

LOGS
~/Library/Application Support/SKY Transfer/logs/

STOP BACKGROUND SERVICES
In Terminal:
launchctl bootout "gui/$(id -u)/com.skytransfer.tunnel"
launchctl bootout "gui/$(id -u)/com.skytransfer.app"
They start again at the next login while their LaunchAgent files remain installed.

VALIDATION
Checked app syntax, single-launcher packaging, HTTP login/logout, upload resume,
downloads and byte ranges, expiry and deletion, capacity limits, version marker,
and cache headers. The glass interface and completed-upload controls were tested
in a browser. The Mac login/launchd lifecycle must be confirmed by running the
launcher outside the Codex sandbox. Full 20 GB internet throughput remains untested.

MULTIPLE FILES
Select or drop up to 100 files per batch, each up to 20 GB. Up to three files upload simultaneously within the 100 GB total storage limit. Browse files and drag-and-drop remain available while transfers are running; each new selection gets its own group. A single-file selection stays a single transfer. Selecting multiple files together creates one group with a ZIP download and group link. Groups have a shared expiry starting when their final file finishes. Individual files inside a group can also be downloaded. Files uploaded in separate selections are never automatically merged. Existing uploads stay separate because their original batch selections were not recorded. Pause stops all active files after their current chunks; Resume continues the remaining queue while the tab stays open. After a page reload, reselect any unfinished originals to resume. Clear queue removes the in-browser queue only, not files already stored on the Mac.

GROUP ZIP DOWNLOADS
ZIP archives are streamed without compression directly from existing files, including ZIP64 support. They do not take extra disk space on the Mac. A group ZIP becomes available only once every file finishes. Streamed ZIP downloads cannot resume as an archive; individual file downloads still support byte ranges. Delete a group to remove all its files. An incomplete group is cleared 24 hours after creation. All files in a group share the chosen 1–3 day expiry.
