#!/usr/bin/env python3
"""Install/update SKY Transfer and register login background services."""
import json,os,plistlib,shutil,signal,subprocess,sys,time,urllib.request
from pathlib import Path
SOURCE=Path(__file__).resolve().parent
TARGET=Path.home()/'Library/Application Support/SKY Transfer'
AGENTS=Path.home()/'Library/LaunchAgents'
SCOPE='gui/'+str(os.getuid())
PYTHON=sys.executable

def command(args,check=False):
    return subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=check)
def local(path='/api/version'):
    try:
        with urllib.request.urlopen('http://127.0.0.1:8787'+path,timeout=2) as response:return response.read()
    except OSError:return None

def main():
    if SOURCE==TARGET:raise RuntimeError('Run the launcher from the extracted download folder.')
    print('Installing SKY Transfer · Glass 1.4',flush=True)
    command([str(SOURCE/'bin/cloudflared'),'--version'],check=True)
    # Identify a previous manual server before replacing files; never stop unrelated listeners.
    old_pid=None
    listeners=command(['/usr/sbin/lsof','-t','-iTCP:8787','-sTCP:LISTEN']).stdout.strip().splitlines()
    if listeners:
        if len(set(listeners))!=1:raise RuntimeError('Port 8787 has multiple listeners. Close the old SKY Transfer Terminal window, then retry.')
        candidate=int(listeners[0]);page=local('/')
        cmd=command(['/bin/ps','-p',str(candidate),'-o','command=']).stdout
        if not page or b'SKY Transfer' not in page or 'server.py' not in cmd:
            raise RuntimeError('Another application is using port 8787. Close it before starting SKY Transfer.')
        old_pid=candidate
    for name in ('tunnel','app'):command(['/bin/launchctl','bootout',SCOPE+'/com.skytransfer.'+name])
    if old_pid:
        try:os.kill(old_pid,signal.SIGTERM)
        except ProcessLookupError:pass
        for _ in range(30):
            if not local('/'):break
            time.sleep(.2)
        if local('/'):raise RuntimeError('The old app did not stop. Close its Terminal window and retry.')
    TARGET.mkdir(parents=True,exist_ok=True);AGENTS.mkdir(parents=True,exist_ok=True)
    for name in ('server.py','tunnel_service.py','web','bin'):
        source=SOURCE/name;dest=TARGET/name
        if source.is_dir():shutil.copytree(source,dest,dirs_exist_ok=True)
        else:shutil.copy2(source,dest)
    (TARGET/'logs').mkdir(exist_ok=True)
    (TARGET/'public-url.txt').write_text('')
    for name,script in [('app','server.py'),('tunnel','tunnel_service.py')]:
        job={'Label':'com.skytransfer.'+name,'ProgramArguments':['/usr/bin/caffeinate','-i',PYTHON,str(TARGET/script)],'WorkingDirectory':str(TARGET),'RunAtLoad':True,'KeepAlive':True,'ThrottleInterval':15,'ProcessType':'Background','EnvironmentVariables':{'PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1'},'StandardOutPath':str(TARGET/'logs'/(name+'.log')),'StandardErrorPath':str(TARGET/'logs'/(name+'-error.log'))}
        agent=AGENTS/('com.skytransfer.'+name+'.plist')
        agent.write_bytes(plistlib.dumps(job));agent.chmod(0o644)
        command(['/bin/launchctl','enable',SCOPE+'/'+job['Label']])
        result=command(['/bin/launchctl','bootstrap',SCOPE,str(agent)])
        if result.returncode:
            raise RuntimeError('macOS could not activate '+name+': '+result.stderr.strip()+'. Run this launcher from Finder or your own Terminal, while logged in.')
        command(['/bin/launchctl','enable',SCOPE+'/'+job['Label']])
    for _ in range(40):
        data=local()
        if data:
            info=json.loads(data)
            if info.get('version')=='glass-1.4':break
        time.sleep(.5)
    else:raise RuntimeError('App did not start. See '+str(TARGET/'logs/app-error.log'))
    print('Local app ready: http://127.0.0.1:8787',flush=True)
    subprocess.run(['/usr/bin/open','http://127.0.0.1:8787/?v=glass-1.4'])
    print('Connecting the internet tunnel…',flush=True)
    for _ in range(60):
        address=(TARGET/'public-url.txt').read_text().strip()
        if address.startswith('https://'):
            print('Public link: '+address,flush=True)
            break
        time.sleep(1)
    else:print('Tunnel is still connecting. Its public link appears in the app automatically. Check logs/tunnel-error.log if it does not appear.',flush=True)
    print('Ready. Local + internet services run in the background and start automatically when you log in. You may close this window.',flush=True)
if __name__=='__main__':
    try:main()
    except (OSError,RuntimeError,subprocess.CalledProcessError) as error:
        print('Setup could not finish: '+str(error),flush=True);sys.exit(1)
