#!/bin/zsh
cd "${0:A:h}"
if ! command -v python3 >/dev/null 2>&1; then
  print 'Python 3.9 or later is required. Install Python for macOS, then open this file again.'
  read '?Press Return to close.'
  exit 1
fi
python3 -B app/install.py
result=$?
read '?Press Return to close this window.'
exit $result
