import tempfile,os,sqlite3,importlib.util,threading,http.client,json,time,zipfile,io
from pathlib import Path
with tempfile.TemporaryDirectory() as tmp:
    os.environ['CLOUD_STORAGE']=tmp
    # Exercise migration from an existing installation without losing its single file.
    db=sqlite3.connect(str(Path(tmp)/'files.sqlite'))
    db.execute('CREATE TABLE files (id TEXT PRIMARY KEY,name TEXT,size INTEGER,offset INTEGER,days INTEGER,created REAL,expires REAL,complete INTEGER)')
    db.execute('INSERT INTO files VALUES (?,?,?,?,?,?,?,?)',('old-file','original.txt',3,3,1,time.time(),time.time()+86400,1));db.commit();db.close()
    (Path(tmp)/'old-file').write_bytes(b'old')
    spec=importlib.util.spec_from_file_location('group_server',str(Path(__file__).resolve().parents[1]/'server.py'))
    c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    server=c.ThreadingHTTPServer(('127.0.0.1',0),c.Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
    cookie=''
    def req(method,path,body=None,headers=None,auth=True):
        h={**({'Cookie':cookie} if auth else {}),**(headers or {})}
        if isinstance(body,dict):body=json.dumps(body);h['Content-Type']='application/json'
        con=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
        con.request(method,path,body,h);r=con.getresponse();out=(r.status,dict(r.getheaders()),r.read());con.close();return out
    assert req('POST','/api/batches',{'files':[]},auth=False)[0]==401
    status,h,_=req('POST','/api/login',{'key':c.KEY});assert status==200;cookie=h['Set-Cookie'].split(';')[0]
    initial=json.loads(req('GET','/api/files')[2]);assert initial['files'][0]['batch_id'] is None
    assert req('GET','/d/old-file',auth=False)[2]==b'old'
    def group(names=['same.txt','same.txt'],sizes=[3,4]):
        status,_,body=req('POST','/api/batches',{'days':2,'files':[{'name':n,'size':s} for n,s in zip(names,sizes)]})
        assert status==201,(status,body)
        return json.loads(body)
    g=group();a,b=g['files'];assert a['batch_id']==b['batch_id']==g['id']
    assert req('GET','/b/'+g['id']+'.zip',auth=False)[0]==410
    assert req('POST','/api/files/'+a['id']+'/chunk',b'abc',{'Upload-Offset':'0'})[0]==200
    assert req('GET','/b/'+g['id']+'.zip',auth=False)[0]==410
    assert req('POST','/api/files/'+b['id']+'/chunk',b'd',{'Upload-Offset':'0'})[0]==200
    assert req('POST','/api/files/'+b['id']+'/chunk',b'efg',{'Upload-Offset':'1'})[0]==200
    before={p.name for p in Path(tmp).iterdir()}
    status,h,body=req('GET','/b/'+g['id']+'.zip',auth=False)
    assert status==200 and h['Content-Type']=='application/zip'
    z=zipfile.ZipFile(io.BytesIO(body));assert z.namelist()==['same.txt','same (2).txt'];assert z.read('same.txt')==b'abc';assert z.read('same (2).txt')==b'defg'
    assert before=={p.name for p in Path(tmp).iterdir()},'ZIP must not create extra disk files'
    listing=json.loads(req('GET','/api/files')[2]);members=[x for x in listing['files'] if x['batch_id']==g['id']]
    assert len({x['expires'] for x in members})==1 and members[0]['expires']>time.time()+1.99*86400
    assert req('POST','/api/files/'+a['id']+'/delete',{})[0]==400
    # A different selection creates an independent group even with identical names/sizes.
    other=group();assert other['id']!=g['id']
    listing=json.loads(req('GET','/api/files')[2]);assert len(listing['batches'])==2
    old_limit=c.LIMIT;c.LIMIT=3
    before=c.DB.execute('SELECT COUNT(*) FROM files').fetchone()[0]
    assert req('POST','/api/batches',{'days':1,'files':[{'name':'x','size':1},{'name':'y','size':1}]})[0]==409
    assert c.DB.execute('SELECT COUNT(*) FROM files').fetchone()[0]==before;c.LIMIT=old_limit
    assert req('POST','/api/batches',{'days':1,'files':[{'name':'x','size':20*10**9+1},{'name':'y','size':1}]})[0]==400
    assert req('POST','/api/batches/'+other['id']+'/delete',{},auth=False)[0]==401
    assert req('POST','/api/batches/'+other['id']+'/delete',{})[0]==200
    assert all(not (Path(tmp)/x['id']).exists() for x in other['files'])
    with c.LOCK:
        c.DB.execute('UPDATE batches SET expires=? WHERE id=?',(time.time()-1,g['id']));c.DB.commit()
    assert req('GET','/b/'+g['id']+'.zip',auth=False)[0]==410
    c.cleanup();assert all(not (Path(tmp)/x['id']).exists() for x in g['files'])
    partial=group()
    with c.LOCK:
        c.DB.execute('UPDATE batches SET created=? WHERE id=?',(time.time()-90000,partial['id']));c.DB.commit()
    c.cleanup();assert all(not (Path(tmp)/x['id']).exists() for x in partial['files'])
    assert (Path(tmp)/'old-file').exists()
    server.shutdown();c.DB.close()
    print('PASS: existing-file migration, authenticated batch creation, separate batches, atomic capacity limits, chunk resume, shared expiry, public streamed ZIP, duplicate filename handling, no ZIP disk copies, delete protection, group deletion, expired and abandoned cleanup.')
