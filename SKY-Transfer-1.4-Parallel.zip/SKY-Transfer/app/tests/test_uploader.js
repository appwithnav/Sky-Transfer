const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
class Element{
  constructor(){this.hidden=false;this.disabled=false;this.textContent='';this.value='';this.children=[];this.listeners={};this.classList={add(){},remove(){},toggle(){}};}
  append(...children){this.children.push(...children);for(const child of children)child.parentElement=this;}
  replaceChildren(...children){this.children=[];this.append(...children);}
  addEventListener(name,fn){this.listeners[name]=fn;}
  setAttribute(){}querySelector(){return null;}click(){this.clickCount=(this.clickCount||0)+1;}reset(){}select(){}
}
const elements=new Map(),get=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
get('days').value='1';
let rows=[],batches=[],serial=0,active=0,peak=0;
const reply=(value,ok=true)=>({ok,json:async()=>JSON.parse(JSON.stringify(value))});
async function fetchMock(url,opts={}){
  if(url==='/api/public-url')return reply({url:''});
  if(url==='/api/files'&&!opts.method)return reply({files:rows,batches,used:0,reserved:0,limit:1e11});
  if(url==='/api/batches'){
    const data=JSON.parse(opts.body),batch={id:'b'+(++serial),expected:data.files.length,created:serial,expires:null,title:'group'};batches.push(batch);
    const files=data.files.map(x=>({id:'f'+(++serial),...x,offset:0,complete:0,created:serial,expires:null,batch_id:batch.id}));rows.push(...files);return reply({id:batch.id,files});
  }
  if(url==='/api/files'){
    const data=JSON.parse(opts.body),row={id:'f'+(++serial),...data,offset:0,complete:0,created:serial,expires:null,batch_id:null};rows.push(row);return reply(row);
  }
  if(url.endsWith('/chunk')){
    const row=rows.find(x=>x.id===url.split('/')[3]);assert.equal(+opts.headers['Upload-Offset'],row.offset);
    active++;peak=Math.max(peak,active);await new Promise(resolve=>setTimeout(resolve,30));
    row.offset+=opts.body.size;row.complete=+(row.offset===row.size);if(row.complete)row.expires=Date.now()/1000+86400;
    const batch=batches.find(b=>b.id===row.batch_id);if(batch&&rows.filter(x=>x.batch_id===batch.id).every(x=>x.complete))batch.expires=row.expires;
    active--;return reply({offset:row.offset,complete:!!row.complete});
  }
  throw Error('Unexpected route '+url);
}
const window={listeners:{},addEventListener(name,fn){this.listeners[name]=fn;}};
const context=vm.createContext({document:{getElementById:get,createElement:()=>new Element()},window,fetch:fetchMock,navigator:{clipboard:{writeText:async()=>{}}},location:{origin:'http://test',replace(){}},console,confirm:()=>true,setInterval:()=>0,setTimeout,performance});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8'),context);
const file=name=>({name,size:16*1024*1024,slice(start,end){return {size:Math.min(end,this.size)-start};}});
(async()=>{
  await new Promise(resolve=>setTimeout(resolve,1));
  get('browseFiles').onclick();assert.equal(get('file').clickCount,1,'Browse invokes the native multiple file picker');
  let prevented=false,stopped=false;
  get('drop').listeners.drop({preventDefault(){prevented=true;},stopPropagation(){stopped=true;},dataTransfer:{files:[file('drop-A.bin'),file('drop-B.bin')]}});
  await new Promise(resolve=>setTimeout(resolve,5));assert(prevented&&stopped);assert(active>=2,'Both dropped files must upload concurrently');
  get('file').onchange({target:{files:[file('browse-C.bin'),file('browse-D.bin')]}});
  const deadline=Date.now()+3000;
  while(vm.runInContext('busy||pendingSelections||!!runPromise',context)&&Date.now()<deadline)await new Promise(resolve=>setTimeout(resolve,10));
  assert.equal(rows.length,4);assert(rows.every(row=>row.complete));assert.equal(batches.length,2,'Separate selections remain separate groups');
  assert.equal(peak,3,'Exactly three simultaneous uploads');assert.equal(get('file').disabled,false);assert.equal(get('transfer').hidden,true);assert.equal(get('transferLabel').textContent,'');
  assert.equal(get('resumeQueue').hidden,true);assert.equal(get('browseFiles').disabled,false);
  console.log('PASS: browse opens picker, dropped files accepted, additional selection during uploads, three concurrent uploads, separate groups, and completion cleanup.');
})().catch(error=>{console.error(error);process.exitCode=1;});
