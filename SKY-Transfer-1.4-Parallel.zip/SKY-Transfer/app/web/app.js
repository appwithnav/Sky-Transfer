const $=id=>document.getElementById(id);
let rows=[],batches=[],busy=false,paused=false;
const bytes=n=>n>=1e9?(n/1e9).toFixed(2)+' GB':n>=1e6?(n/1e6).toFixed(1)+' MB':(n/1e3).toFixed(1)+' KB';
const say=s=>$('message').textContent=s;
async function api(path,options={}){const r=await fetch(path,options);const data=await r.json();if(!r.ok)throw new Error(data.error||'Request failed');return data;}
const post=(path,data)=>api(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data||{})});
async function refresh(){try{const data=await api('/api/files');rows=data.files;batches=data.batches||[];$('login').hidden=true;$('dashboard').hidden=false;$('logout').hidden=false;$('storageLabel').textContent=bytes(data.used)+' of 100 GB used';$('storageDetail').textContent=bytes(data.reserved)+' reserved, including unfinished uploads';$('capacity').value=data.reserved/data.limit*100;render();}catch(e){if(e.message==='Please sign in'){$('login').hidden=false;$('dashboard').hidden=true;$('logout').hidden=true;}else say(e.message);}}
function downloadButton(url,label){
  const link=document.createElement('a');link.className='downloadAction';link.href=url;link.textContent=label;link.setAttribute('download','');return link;
}
function copyButton(path,label='Copy link'){
  const button=document.createElement('button');button.textContent=label;
  button.onclick=async()=>{const url=(publicBase||location.origin)+path;try{await navigator.clipboard.writeText(url);say('Link copied. Keep your Mac awake while the recipient downloads.');}catch{let input=button.parentElement.querySelector('input.shareLink');if(!input){input=document.createElement('input');input.className='shareLink';input.readOnly=true;input.setAttribute('aria-label','Share link');button.parentElement.append(input);}input.value=url;input.select();say('Copy the selected link.');}};
  return button;
}
function deleteButton(path,name){
  const button=document.createElement('button');button.textContent='Delete';button.className='danger';button.disabled=busy;
  button.onclick=async()=>{if(!confirm('Delete '+name+' and invalidate its download links?'))return;try{await post(path);await refresh();}catch(error){say(error.message);}};
  return button;
}
function render(){
  const root=$('files');root.replaceChildren();
  const items=[...batches.map(batch=>({group:batch,created:batch.created})),...rows.filter(row=>!row.batch_id).map(row=>({file:row,created:row.created}))].sort((a,b)=>b.created-a.created);
  if(!items.length){const p=document.createElement('p');p.textContent='No transfers yet. Your next big file starts above.';root.append(p);}
  for(const item of items){
    if(item.file){
      const row=item.file,div=document.createElement('div');div.className='file';
      const info=document.createElement('div');info.className='info';
      const name=document.createElement('strong');name.textContent=row.name;
      const meta=document.createElement('small');meta.textContent=bytes(row.size)+' · '+(row.complete?'Expires '+new Date(row.expires*1000).toLocaleString():'Paused at '+bytes(row.offset)+' · select the same file to resume');
      info.append(name,meta);div.append(info);
      if(row.complete)div.append(downloadButton('/d/'+row.id,'Download'),copyButton('/d/'+row.id));
      div.append(deleteButton('/api/files/'+row.id+'/delete',row.name));root.append(div);continue;
    }
    const batch=item.group,members=rows.filter(row=>row.batch_id===batch.id).sort((a,b)=>a.created-b.created);
    const complete=members.filter(row=>row.complete).length;
    const ready=Boolean(batch.expires)&&complete===batch.expected&&members.length===batch.expected;
    const group=document.createElement('section');group.className='fileGroup';
    const top=document.createElement('div');top.className='file';
    const info=document.createElement('div');info.className='info';
    const title=document.createElement('strong');title.textContent='▤ '+batch.title;
    const meta=document.createElement('small');
    meta.textContent=batch.expected+' files · '+bytes(members.reduce((sum,row)=>sum+row.size,0))+' · '+(ready?'Expires '+new Date(batch.expires*1000).toLocaleString():complete+'/'+batch.expected+' uploaded · ZIP ready when all files finish');
    info.append(title,meta);top.append(info);
    if(ready)top.append(downloadButton('/b/'+batch.id+'.zip','Download ZIP'),copyButton('/b/'+batch.id+'.zip','Copy group link'));
    top.append(deleteButton('/api/batches/'+batch.id+'/delete','this group of '+batch.expected+' files'));
    const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent='View '+members.length+' files';details.append(summary);
    for(const row of members){
      const child=document.createElement('div');child.className='groupMember';const label=document.createElement('span');label.textContent=row.name+' · '+bytes(row.size)+(row.complete?'':' · '+Math.round(row.offset/row.size*100)+'% uploaded');child.append(label);
      if(row.complete)child.append(downloadButton('/d/'+row.id,'Download'));
      details.append(child);
    }
    group.append(top,details);root.append(group);
  }
}
function matchingGroup(files){
  for(const batch of batches.filter(batch=>!batch.expires&&batch.expected===files.length&&!uploadQueue.some(job=>job.row?.batch_id===batch.id))){
    const remaining=rows.filter(row=>row.batch_id===batch.id),matched=[];
    if(remaining.length!==files.length)continue;
    for(const job of files){const index=remaining.findIndex(row=>row.name===job.file.name&&row.size===job.file.size);if(index<0)break;matched.push(remaining.splice(index,1)[0]);}
    if(matched.length===files.length)return matched;
  }
  return null;
}
$('loginForm').onsubmit=async e=>{e.preventDefault();try{await post('/api/login',{key:$('key').value});$('key').value='';say('');await refresh();}catch(e){say(e.message);}};
$('logout').onclick=async()=>{
  if(busy||pendingSelections){say('Pause uploads and wait for selections to finish before signing out.');return;}
  $('logout').disabled=true;
  try{
    await post('/api/logout');
    uploadQueue=[];paused=false;showQueueControls();
    rows=[];batches=[];
    $('files').replaceChildren();
    $('dashboard').hidden=true;
    $('logout').hidden=true;
    $('login').hidden=false;
    $('loginForm').reset();
    say('');
    location.replace('/?signedout='+Date.now());
  }catch(e){say('Could not sign out: '+e.message+'. Please try again.');}
  finally{$('logout').disabled=false;}
};
$('refresh').onclick=refresh;
let uploadQueue=[],pendingSelections=0,selectionChain=Promise.resolve(),runPromise=null,stoppingError='';
const PARALLEL_UPLOADS=3;
const remainingJobs=()=>uploadQueue.filter(job=>job.status!=='done');
function queueRemaining(){return remainingJobs().length;}
function showQueueControls(){
  const pending=queueRemaining()>0;
  $('resumeQueue').hidden=busy||!pending;
  $('clearQueue').hidden=busy||!pending;
  $('resumeQueue').textContent='Resume '+queueRemaining()+' remaining file'+(queueRemaining()===1?'':'s');
}
function updateUploadView(){
  const total=uploadQueue.reduce((sum,job)=>sum+job.file.size,0);
  const uploaded=uploadQueue.reduce((sum,job)=>sum+(job.offset||0),0);
  const active=uploadQueue.filter(job=>job.status==='uploading').length;
  const waiting=uploadQueue.filter(job=>job.status==='queued').length;
  $('uploadProgress').value=total?uploaded/total*100:0;
  $('transferLabel').textContent=active+' uploading · '+waiting+' waiting · '+(total?Math.floor(uploaded/total*100):0)+'% overall';
  const list=$('uploadItems');list.replaceChildren();
  for(const job of uploadQueue.filter(job=>job.status!=='done')){
    const item=document.createElement('div');item.className='uploadItem';
    const name=document.createElement('span');name.textContent=job.file.name;
    const status=document.createElement('small');status.textContent=job.status==='uploading'?Math.floor((job.offset||0)/job.file.size*100)+'%':job.status==='queued'?'Waiting':'Paused';
    item.append(name,status);list.append(item);
  }
  showQueueControls();
}
$('pause').onclick=()=>{paused=true;$('pause').disabled=true;say('Pausing all uploads after their current chunks finish…');};
$('resumeQueue').onclick=()=>{paused=false;runQueue();};
$('clearQueue').onclick=()=>{uploadQueue=[];paused=false;stoppingError='';showQueueControls();say('Queue cleared. Stored unfinished uploads remain until their 24-hour expiry.');};
async function upload(files){
  const selected=Array.from(files||[]);$('file').value='';
  if(!selected.length){say('No files selected. Use Browse files or drop files into the upload area.');return;}
  if(selected.length>100){say('Choose up to 100 files per selection.');return;}
  const invalid=selected.find(file=>!file.size||file.size>20e9);
  if(invalid){say('Cannot upload '+invalid.name+': each file must be non-empty and no larger than 20 GB.');return;}
  const days=Number($('days').value);
  pendingSelections++;say('Preparing '+selected.length+' selected file'+(selected.length===1?'':'s')+'…');
  selectionChain=selectionChain.then(async()=>{
    try{
      await refresh();
      const jobs=selected.map(file=>({file,row:null,offset:0,status:'queued'}));
      if(selected.length>1){
        const existing=matchingGroup(jobs);
        if(existing&&confirm('Resume the unfinished group? Continue only if these are the exact same unchanged files.')){
          jobs.forEach((job,index)=>job.row=existing[index]);
        }else{
          const group=await post('/api/batches',{days,files:selected.map(file=>({name:file.name,size:file.size}))});
          jobs.forEach((job,index)=>job.row=group.files[index]);
        }
      }else{
        const file=selected[0];
        const taken=new Set(uploadQueue.map(job=>job.row?.id));
        let candidate=rows.find(row=>!row.batch_id&&!row.complete&&row.name===file.name&&row.size===file.size&&!taken.has(row.id));
        if(candidate&&!confirm('Resume '+file.name+'? Continue only if this is the exact same unchanged file.'))candidate=null;
        jobs[0].row=candidate||await post('/api/files',{name:file.name,size:file.size,days});
      }
      for(const job of jobs){job.offset=job.row.offset;job.status=job.row.complete?'done':'queued';}
      if(!busy&&!queueRemaining())uploadQueue=[];
      uploadQueue.push(...jobs);
      await refresh();
      say(paused?'Files added. Press Resume to start.':selected.length+' file'+(selected.length===1?'':'s')+' added. You can browse or drop more files while uploading.');
    }catch(error){say('Could not add these files: '+error.message);}
    finally{
      pendingSelections--;
      if(!paused&&queueRemaining())runQueue();
      else showQueueControls();
    }
  });
  await selectionChain;
}
async function uploadJob(job){
  const file=job.file;
  // Refresh offsets after a lost response so Resume never sends a stale chunk.
  const current=rows.find(row=>row.id===job.row.id);
  if(!current)throw new Error(file.name+' is expired or deleted. Clear the queue and select it again');
  job.row=current;job.offset=current.offset;
  if(current.complete){job.status='done';updateUploadView();return;}
  job.status='uploading';updateUploadView();
  while(job.offset<file.size&&!paused){
    const chunk=file.slice(job.offset,job.offset+8*1024*1024);
    const result=await api('/api/files/'+job.row.id+'/chunk',{method:'POST',headers:{'Upload-Offset':String(job.offset),'Content-Type':'application/octet-stream'},body:chunk});
    job.offset=result.offset;job.row.offset=result.offset;job.row.complete=result.complete?1:0;updateUploadView();
  }
  job.status=job.offset===file.size?'done':'paused';updateUploadView();
}
function runQueue(){
  if(runPromise||paused||!queueRemaining())return runPromise;
  busy=true;stoppingError='';
  for(const job of remainingJobs())job.status='queued';
  $('pause').disabled=false;$('transfer').hidden=false;updateUploadView();render();
  runPromise=(async()=>{
    try{
      await refresh();
      async function worker(){
        while(!paused){
          const job=uploadQueue.find(item=>item.status==='queued');
          if(!job){
            if(pendingSelections||uploadQueue.some(item=>item.status==='uploading')){await new Promise(resolve=>setTimeout(resolve,25));continue;}
            return;
          }
          // Claim synchronously before awaiting so each file belongs to one worker.
          job.status='uploading';
          try{await uploadJob(job);}
          catch(error){job.status='paused';stoppingError=error.message;paused=true;updateUploadView();}
        }
      }
      await Promise.all(Array.from({length:PARALLEL_UPLOADS},()=>worker()));
      if(stoppingError)say(stoppingError+'. Pause/resume state is saved in this tab. Use Resume to retry.');
      else if(queueRemaining())say('Uploads paused. '+queueRemaining()+' file'+(queueRemaining()===1?'':'s')+' remaining.');
      else{
        const count=uploadQueue.length;
        say(count+' file'+(count===1?'':'s')+' uploaded. Download or copy the links below.');uploadQueue=[];
      }
    }catch(error){paused=true;say(error.message+'. Use Resume to retry.');}
    finally{
      busy=false;runPromise=null;
      for(const job of remainingJobs())if(job.status==='queued')job.status='paused';
      $('pause').disabled=true;$('transfer').hidden=true;$('transferLabel').textContent='';$('uploadProgress').value=0;$('uploadItems').replaceChildren();
      showQueueControls();await refresh();
      // A selection registered while the previous workers were finishing.
      if(!paused&&queueRemaining())runQueue();
    }
  })();
  return runPromise;
}
$('file').onchange=event=>upload(event.target.files);
$('browseFiles').onclick=()=>{$('file').value='';$('file').click();};
let dragDepth=0;
$('drop').addEventListener('dragenter',event=>{event.preventDefault();dragDepth++;$('drop').classList.add('drag');});
$('drop').addEventListener('dragover',event=>{event.preventDefault();event.stopPropagation();if(event.dataTransfer)event.dataTransfer.dropEffect='copy';});
$('drop').addEventListener('dragleave',event=>{event.preventDefault();dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)$('drop').classList.remove('drag');});
$('drop').addEventListener('drop',event=>{
  event.preventDefault();event.stopPropagation();dragDepth=0;$('drop').classList.remove('drag');
  upload(Array.from(event.dataTransfer?.files||[]));
});
window.addEventListener('dragover',event=>{if(Array.from(event.dataTransfer?.types||[]).includes('Files'))event.preventDefault();});
window.addEventListener('drop',event=>{if(Array.from(event.dataTransfer?.types||[]).includes('Files')){event.preventDefault();say('Drop files into the upload area, or use Browse files.');}});
refresh();setInterval(()=>{if(!busy&& !$('dashboard').hidden)refresh();},30000);

let publicBase='';
async function updateInternet(){try{const data=await api('/api/public-url');publicBase=data.url||'';$('internetStatus').textContent=publicBase?'Internet · Link ready':'Internet · Connecting…';$('publicLink').hidden=!publicBase;if(publicBase)$('publicLink').href=publicBase;}catch{$('internetStatus').textContent='Internet · Unavailable';}}
updateInternet();setInterval(updateInternet,10000);

api('/api/version').then(data=>{if(data.version!=='glass-1.4'){$('serverNotice').hidden=false;$('serverNotice').textContent='Update ready: run the new Start SKY Transfer.command once to activate simultaneous uploads.';}}).catch(()=>{});
